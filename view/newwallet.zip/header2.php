<?php if (!defined("IN_WALLET")) { die("Auth Error!"); } ?>
<!DOCTYPE HTML>

<html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
        	function hideURLbar(){ window.scrollTo(0,1); } </script>
	<link href="/view/css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="/view/css/creditly.css" type="text/css" media="all" />
	<link rel="stylesheet" href="/view/css/easy-responsive-tabs.css">
	<script src="/view/js/jquery.min.js"></script>
	<link href="/view/css/font-awesome.css" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Mirza:400,500,600,700&amp;subset=arabic,latin-ext" rel="stylesheet">
        <link href="assets/css/wallet.css" rel="stylesheet">
        <link href="assets/css/wallet.css" rel="stylesheet">
        <link href="assets/css/languages.min.css" rel="stylesheet">
        <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.6.0/moment.min.js"></script>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <script src="assets/js/bootstrap.min.js"></script>

        <!-- Bootstrap include stuff -->
<?php /*
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/wallet.css" rel="stylesheet">
	<link href="assets/css/languages.min.css" rel="stylesheet">
        <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.6.0/moment.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
*/ ?>
        <title><?=$fullname?> Wallet</title>
    </head>
    <body>
